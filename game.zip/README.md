# Ashes of the Iron Empire (เถ้าถ่านแห่งจักรวรรดิเหล็ก)

Visual Novel + Strategy / Sandbox game built with Ren'Py

## โครงสร้างโปรเจกต์

### ไฟล์ที่สร้างแล้ว:

1. **game/options.rpy** - การตั้งค่าเกม (ชื่อเกม, เวอร์ชัน)
2. **game/characters.rpy** - ตัวละครทั้งหมด
3. **game/variables.rpy** - ตัวแปรเกมและระบบแก่นพลังงาน
4. **game/script.rpy** - สคริปต์หลักของเกม

### ทรัพยากรที่ต้องเพิ่ม (Images/Backgrounds):

#### Backgrounds (วางใน `game/images/bg/`):
- `bg room` - Background พื้นฐาน (มีอยู่แล้ว)
- `bg imperial_palace` - พระราชวังจักรวรรดิ
- `bg command_room_night` - ห้องบังคับการกลางคืน
- `bg tank_garage` - โรงเก็บรถถัง
- `bg wasteland` - ทุ่งรกร้าง
- `bg destroyed_village` - หมู่บ้านที่ถูกทำลาย
- `bg mountain_path` - ทางภูเขา
- `bg dragon_lair` - รังมังกร
- `bg dragon_lair_battle` - การต่อสู้กับมังกร
- `bg wasteland_destroyed` - ทุ่งรกร้างหลังจักรวรรดิตาย
- `bg capital_destroyed` - เมืองหลวงที่ถูกทำลาย

#### Character Sprites (วางใน `game/images/`):
- `emperor serious` - จักรพรรดิ
- `victor neutral` - วิกเตอร์ (neutral)
- `victor worried` - วิกเตอร์ (worried)
- `ellen neutral` - เอลเลน (neutral)
- `ellen worried` - เอลเลน (worried)
- `lucia neutral` - ลูเซีย (neutral)
- `lucia worried` - ลูเซีย (worried)
- `chronozar` - มังกรครอโนซาร์
- `villager sad` - ชาวบ้าน

#### Audio (วางใน `game/audio/`):
- `rain.ogg` - เสียงฝน
- `cannon_distant.ogg` - เสียงปืนใหญ่ระยะไกล

## ระบบเกม

### ตัวแปรหลัก:

1. **Ideology Variables** (ส่งผลต่อเส้นทางและ ending):
   - `ideology_loyalty` (-100 ถึง 100): ความภักดีต่อจักรวรรดิ
   - `ideology_ruler` (-100 ถึง 100): ความอยากเป็นผู้นำ
   - `ideology_mercenary` (-100 ถึง 100): ความสนใจในชีวิตรับจ้าง

2. **Crew Relationships** (0-100):
   - `crew_victor_trust`
   - `crew_ellen_trust`
   - `crew_lucia_trust`

3. **Tank System**:
   - `tank_name` - ชื่อรถถัง (ผู้เล่นตั้งเอง)
   - `tank_operational` - สถานะรถถัง
   - `core_energy` - พลังงานแก่น (0-100)
   - `last_core_absorption` - วันล่าสุดที่ดูดซับพลังงาน

### ระบบแก่นพลังงาน

ผู้เล่นต้องดูดซับพลังงานจากแก่นเวลาในรถถังทุกสัปดาห์ ไม่อย่างนั้นจะได้รับผลกระทบ

ใช้ฟังก์ชัน `check_core_absorption()` เพื่อตรวจสอบ และ `absorb_core_energy()` เพื่อดูดซับ

## โครงเรื่อง

### Act I: จักรวรรดิที่กำลังร้าว
- ฉากเปิด: พบจักรพรรดิ
- เตรียมการเดินทาง
- เดินทางไปภูเขาสุดขอบโลก

### Act II: เผชิญหน้ามังกร & จุดหักเห
- เจอมังกรครอโนซาร์
- การสนทนาเชิงปรัชญา
- การต่อสู้และจักรวรรดิถูกทำลาย

### Act III: โลกหลังจักรวรรดิ
- ตื่นขึ้นในโลกใหม่
- เลือกเส้นทาง (Warlord / Mercenary / Join Faction)

## เส้นทาง (Routes)

1. **Warlord** - สร้างอาณาจักรใหม่
2. **Mercenary** - เป็นทหารรับจ้าง
3. **Join Faction** - เข้าร่วมฝ่าย (Free Cities / Trade Federation / Imperial Restoration)

## การรันเกม

1. เปิด Ren'Py Launcher
2. เลือกโปรเจกต์ "TEST"
3. กด "Launch Project" เพื่อทดสอบเกม

## หมายเหตุ

- เกมนี้เป็น Demo ที่ครอบคลุม Act I, Act II และจุดเริ่มต้นของ Act III
- เนื้อหาต่อจากนี้จะพัฒนาเพิ่มเติมในอนาคต
- ต้องเพิ่มภาพและเสียงตามที่ระบุข้างต้น

