# คำแนะนำการเพิ่มฟอนต์ไทย

## วิธีการเพิ่มฟอนต์ไทย

เกมนี้รองรับฟอนต์ไทยหลายตัว หากคุณมีไฟล์ฟอนต์ไทย ให้นำไปวางในโฟลเดอร์ `game/` (เช่นเดียวกับไฟล์ .rpy)

### ฟอนต์ที่แนะนำ (ลำดับความ優先):

1. **Noto Sans Thai** (แนะนำมากที่สุด)
   - ดาวน์โหลด: https://fonts.google.com/noto/specimen/Noto+Sans+Thai
   - ชื่อไฟล์ที่ต้องใช้: `NotoSansThai-Regular.ttf`
   - วางไฟล์ที่: `game/NotoSansThai-Regular.ttf`

2. **Srisakdi** (ฟอนต์ไทยมาตรฐาน)
   - มักจะมาพร้อมกับ Windows Thai language pack
   - ชื่อไฟล์ที่ต้องใช้: `Srisakdi-Regular.ttf` หรือ `Srisakdi.ttf`
   - วางไฟล์ที่: `game/Srisakdi-Regular.ttf`

3. **Kanit** (ฟอนต์ไทยสมัยใหม่)
   - ดาวน์โหลด: https://fonts.google.com/specimen/Kanit
   - ชื่อไฟล์ที่ต้องใช้: `Kanit-Regular.ttf` หรือ `Kanit.ttf`
   - วางไฟล์ที่: `game/Kanit-Regular.ttf`

4. **TH Sarabun New** (ฟอนต์ไทยของ Microsoft)
   - ดาวน์โหลด: จาก Microsoft Typography
   - ชื่อไฟล์ที่ต้องใช้: `THSarabunNew-Regular.ttf` หรือ `THSarabunNew.ttf`
   - วางไฟล์ที่: `game/THSarabunNew-Regular.ttf`

## วิธีการดาวน์โหลดและติดตั้ง

### Noto Sans Thai (แนะนำ):

1. ไปที่ https://fonts.google.com/noto/specimen/Noto+Sans+Thai
2. คลิก "Download family"
3. แตกไฟล์ zip
4. หาไฟล์ `NotoSansThai-Regular.ttf`
5. คัดลอกไปวางใน `game/` folder ของโปรเจกต์

### หากไม่มีฟอนต์ไทย

เกมจะใช้ `DejaVuSans.ttf` ซึ่งรองรับ Unicode รวมถึงภาษาไทย แต่การแสดงผลจะไม่สวยเท่าฟอนต์ที่ออกแบบมาสำหรับภาษาไทยโดยเฉพาะ

## ตรวจสอบการทำงาน

หลังจากเพิ่มฟอนต์แล้ว:

1. เปิด Ren'Py Launcher
2. เลือกโปรเจกต์
3. กด "Force Recompile" เพื่อให้แน่ใจว่าเกมจะโหลดฟอนต์ใหม่
4. เปิดเกมและตรวจสอบว่าฟอนต์แสดงผลถูกต้อง

## โครงสร้างโฟลเดอร์ตัวอย่าง:

```
game/
  ├── NotoSansThai-Regular.ttf  ← วางฟอนต์ที่นี่
  ├── script.rpy
  ├── characters.rpy
  ├── variables.rpy
  └── ...
```

## หมายเหตุ

- เกมจะลองใช้ฟอนต์ตามลำดับความ優先ที่ระบุไว้
- หากพบฟอนต์ใดๆ จะใช้ฟอนต์นั้นทันที
- หากไม่พบฟอนต์ไทยเลย จะใช้ DejaVuSans ซึ่งรองรับภาษาไทย (แต่ไม่สวยเท่า)
- การตั้งค่า language เป็น "thai" จะช่วยให้การตัดคำและการแสดงผลภาษาไทยดีขึ้น

