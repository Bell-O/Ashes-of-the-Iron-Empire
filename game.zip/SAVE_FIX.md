# แก้ไขปัญหา Save Files ไม่เข้ากัน

## ปัญหา:
Error: "Couldn't find a place to stop rolling back. Perhaps the script changed in an incompatible way?"

## สาเหตุ:
สคริปต์เกมเปลี่ยนแปลงไปมาก (เพิ่มไฟล์ใหม่, เปลี่ยนโครงสร้าง) ทำให้ save files เก่าไม่เข้ากัน

## วิธีแก้ไข (เลือก 1 วิธี):

### วิธีที่ 1: ลบ Save Files ด้วย Ren'Py Launcher (แนะนำมากที่สุด) ⭐

1. เปิด **Ren'Py Launcher**
2. เลือกโปรเจกต์ **"TEST"** หรือ **"Ashes of the Iron Empire"**
3. กดปุ่ม **"Delete Persistent"** (ด้านล่างซ้าย)
4. รันเกมใหม่ - จะสร้าง save files ใหม่ที่เข้ากันได้

### วิธีที่ 2: ลบ Save Files ด้วยตนเอง

1. ไปที่โฟลเดอร์ `game/saves/`
2. ลบไฟล์ทั้งหมดในโฟลเดอร์นั้น (หรือลบโฟลเดอร์ `saves` ทั้งหมด)
3. รันเกมใหม่

### วิธีที่ 3: เปลี่ยน Save Directory (ทำแล้ว)

เราได้เปลี่ยน save directory ไปเป็น `"AshesOfTheIronEmpire-2025"` แล้ว 
เกมจะสร้าง save files ใหม่ในโฟลเดอร์ใหม่โดยอัตโนมัติ

**แต่ถ้ายังมี error:** ต้องลบ save files เก่าในโฟลเดอร์เดิมด้วย

### วิธีที่ 2: เปลี่ยน Save Directory

แก้ไขไฟล์ `game/options.rpy` บรรทัด 153:
```python
define config.save_directory = "TEST-1763670928"  # เปลี่ยนตัวเลขท้ายให้ต่างกัน
```

### วิธีที่ 3: เริ่มเกมใหม่

กด "New Game" แทน "Continue" หรือ "Load"

## หมายเหตุ:
- Save files เก่าจะใช้งานไม่ได้หลังจากสคริปต์เปลี่ยนไปมาก
- แนะนำให้ลบ save files เก่าเมื่อพัฒนาสคริปต์ใหม่
- Save files ใหม่จะทำงานได้ปกติ

